#!/bin/bash
basedircounts=$(pwd)
for i in counts/*; do cp cs1.sh "$i" && cp cs2.sh "$i"; done
for i in counts/*; do cd "$i" && ./cs1.sh && ./cs2.sh && cd "$basedircounts"; done
