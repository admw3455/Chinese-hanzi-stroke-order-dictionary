# -*- coding: utf-8-*-
#run this
# run runfirst.sh
# run runsecond.sh

import os
import HTMLParser
import io

with io.open('scc.txt', encoding='utf8') as scclist:
	scc=scclist.read()

writefilepath=False
pinyinword=False
cncharacter=False
englishtranslation=False

htmlconverter = HTMLParser.HTMLParser()
with io.open('dictionary.txt', encoding='utf8') as dictionary:
	dictionaryfile=dictionary.readlines()

pinyinbarelist=[]

rootdir = os.getcwd()
for subdir, dirs, files in os.walk(rootdir):
	for file in files:
				if 'removelines.py' in file or '.html' in file or 'dictionary.txt' in file or 'createwordlist.py' in file or 'createdictionarylist.py' in file or 'scc.txt' in file or 'wordlist.txt' in file:
					pass
				else:
					openfile=file
					writefilepath=('html/' + openfile + '.html')
					cncharactertemp="&#" + file.split('.')[0] + ";"
					cncharacter=htmlconverter.unescape(cncharactertemp)
					if cncharacter in scc:
						with open(openfile) as file:
							tempfile = file.readlines()
							#writefile.write(u'<meta http-equiv="refresh" content="24">')		
						try:
							for qzz in dictionaryfile:
								if (qzz[14:15]) == cncharacter:
									if 'definition' in qzz:
										pqzz1=qzz.split('pinyin')[1].split('[')[1].split(']')[0].replace('"','')
										if len(pqzz1) > 0:
											#writefile.write(u'<h1>%s: %s (%s)</h1>' % (cncharacter, qzz.split('"')[7],pqzz1))
											pinyinword=pqzz1
											englishtranslation=qzz.split('"')[7].replace('a1b1c1q4q9q0d3','q0q0q0')
											pass
										else:
											#writefile.write(u'<h1>%s: %s</h1>' % (cncharacter, qzz.split('"')[7]))
											pass
									else:
										pass
									try:
										qzz1=qzz.split('composition')
										#writefile.write(u'<h4>%s: %s</h4>' % (cncharacter, qzz1[1].split('"')[2]))
										qzz2a=(qzz1[1]).split('{')
										qzz2b=qzz2a[1].split('}')
										qzz2=qzz2b[0].split('radical')
										#writefile.write(u'<h4>%s</h4>' % qzz2[0].replace('"',' '))
										qzz3=(qzz2b[1].split('matches'))
										#writefile.write(u'<h4>%s</h4>' % qzz3[0][1:-2].replace('"',' '))
									except:
										pass
						except:
							print(file)
						for i in tempfile[0:1]:
							#writefile.write(u'%s' % i)
							pass
						for i in tempfile[7:]:
							#writefile.write(u'%s' % i)
							pass
						#writefile.write(u'</html>')
					if pinyinword == 'False' or pinyinword == False:
						pass
					else:
						pinyinbare=pinyinword.replace(u"ā","a").replace(u"á","a").replace(u"ǎ","a").replace(u"à","a").replace(u"ē","e").replace(u"é","e").replace(u"ě","e").replace(u"è","e").replace(u"ī","i").replace(u"í","i").replace(u"ǐ","i").replace(u"ì","i").replace(u"ō","o").replace(u"ó","o").replace(u"ǒ","o").replace(u"ò","o").replace(u"ū","u").replace(u"ú","u").replace(u"ǔ","u").replace(u"ù","u").replace(u"ǖ","u").replace(u"ǘ","u").replace(u"ǚ","u").replace(u"ǜ","u")
						if pinyinbare not in pinyinbarelist:
							pinyinbarelist.append(pinyinbare)
						try:
							writefilepathdic=('dic/' + pinyinbare + '.html')
							writefile=io.open(writefilepathdic, 'a', encoding='utf8')
							writefile.write('%s:<a href="%s" href title="%s">%s</a>\n' % (pinyinword, writefilepath, pinyinword, cncharacter))
							writefile.close()
						except:
							print('error')
					writefilepath=False
					writefilepathdic=False
					pinyinword=False
					cncharacter=False
					englishtranslation=False
					pinyinbare=False

writefile=io.open('pinyinbarelist.html', 'a', encoding='utf8')
for i in pinyinbarelist:
	writefile.write('%s:<a href="%s.html">%s</a></br>\n' % (i,i,i))
writefile.close()

