#!/bin/bash
basedircounts=$(pwd)
if [ -d "counthtml" ]; then rm -rf counthtml; fi
mkdir counthtml
for i in counts/*/wordlist.txt; do namefilecount=$(dirname "$i") && namefilecount="${namefilecount##*/}.html" && cp "$i" counthtml/"$namefilecount"; done
for i in counthtml/*; do countvariable=$(cat "$i") && if [ ${#countvariable} -lt 10 ] ; then rm "$i"; fi ; done
cd counthtml
for i in *; do numbervar=$(printf "%02d" ${i%.*}) && echo "$numbervar:<a href=$i>$numbervar strokes</a>" >> countstroke.html; done
sort -d countstroke.html -o countstroke.html
sed -i  's/^[^:]*://g' countstroke.html
cd ..
for i in counthtml/*; do sed -i "s/a><a/a> <a/g" "$i"; done
for i in counthtml/*; do cat insert.txt | cat - "$i" > temp && mv temp "$i"; done
for i in counthtml/*; do echo "/html" >> "$i"; done
cd counthtml
sed -i "s/<\/a>/<\/a><\/br>/g" countstroke.html
cd ..
