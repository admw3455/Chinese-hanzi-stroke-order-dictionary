#!/bin/bash
basedircounts=$(pwd)
for i in counts/*; do cp runfirst.sh "$i" && cp pinyinconvert.sh "$i" && cp pinyinrevert.sh "$i"; done
for i in counts/*; do cd "$i" && ./runfirst.sh && cd "$basedircounts"; done
