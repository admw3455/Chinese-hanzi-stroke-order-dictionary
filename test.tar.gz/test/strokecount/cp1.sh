#!/bin/bash
basedircounts=$(pwd)
for i in counts/*; do cp createdic.py "$i" && cp dictionary.txt "$i" && cp scc.txt "$i"; done
for i in counts/*; do cd "$i" && mkdir dic && python createdic.py && cd "$basedircounts"; done
