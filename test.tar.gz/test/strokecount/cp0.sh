#!/bin/bash
if [ -d counts ]; then rm -rf counts; fi
mkdir counts
basedircounts=$(pwd)
for i in svgs/*.svg; do if [ -d counts/$(cat "$i" | grep -c '<clipPath id="') ]; then :; else mkdir counts/$(cat "$i" | grep -c '<clipPath id="'); fi ; done
for i in svgs/*.svg; do cp "$i" counts/$(cat "$i" | grep -c '<clipPath id="'); done
