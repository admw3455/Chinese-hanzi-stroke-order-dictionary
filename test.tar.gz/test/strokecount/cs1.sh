#!/bin/bash
cd dic
for i in *; do echo "${i%.*}" >> filelist.txt; done
mv filelist.txt ../
cd ..
sort -d filelist.txt -o filelist.txt
sed -e 's/$/.html/' -i filelist.txt
