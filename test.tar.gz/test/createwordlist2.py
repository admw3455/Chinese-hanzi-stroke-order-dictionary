import io
import os

with io.open('wordlist_sorted.txt', encoding='utf8') as wordlist:
	wordlistfile=wordlist.readlines()

os.system('echo "" > wordlist_finished.txt')

writefile=io.open('wordlist_finished.txt', 'a', encoding='utf8')

for i in wordlistfile:
	writefile.write(i.split(':')[1])
writefile.close()
