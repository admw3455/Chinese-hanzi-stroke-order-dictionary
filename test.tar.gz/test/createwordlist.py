#run this
#run sed -i "s/;;;/\n/g" wordlist.txt
#run sort wordlist.txt >> wordlist_sorted.txt
#run sed -i '/^[[:space:]]*$/d' wordlist_sorted.txt
#run createwordlist2.py
#run tr -d '\n' < wordlist_finished.txt >> wordlist_finished_copy.txt

import os
import HTMLParser
import io

with io.open('scc.txt', encoding='utf8') as scclist:
	scc=scclist.read()

writefilepath=False
pinyinword=False
cncharacter=False
englishtranslation=False

htmlconverter = HTMLParser.HTMLParser()
with io.open('dictionary.txt', encoding='utf8') as dictionary:
	dictionaryfile=dictionary.readlines()

os.system('echo "" > wordlist.txt')

rootdir = os.getcwd()
for subdir, dirs, files in os.walk(rootdir):
	for file in files:
				if 'removelines.py' in file or '.html' in file or 'dictionary.txt' in file or 'createwordlist.py' in file or 'createdictionarylist.py' in file or 'scc.txt' in file or 'wordlist.txt' in file:
					pass
				else:
					openfile=file
					writefilepath=('html/' + openfile + '.html')
					writefile=io.open('wordlist.txt', 'a', encoding='utf8')
					cncharactertemp="&#" + file.split('.')[0] + ";"
					cncharacter=htmlconverter.unescape(cncharactertemp)
					if cncharacter in scc:
						with open(openfile) as file:
							tempfile = file.readlines()
							#writefile.write(u'<meta http-equiv="refresh" content="24">')		
						try:
							for qzz in dictionaryfile:
								if (qzz[14:15]) == cncharacter:
									if 'definition' in qzz:
										pqzz1=qzz.split('pinyin')[1].split('[')[1].split(']')[0].replace('"','')
										if len(pqzz1) > 0:
											#writefile.write(u'<h1>%s: %s (%s)</h1>' % (cncharacter, qzz.split('"')[7],pqzz1))
											pinyinword=pqzz1
											pass
										else:
											#writefile.write(u'<h1>%s: %s</h1>' % (cncharacter, qzz.split('"')[7]))
											pass
									else:
										pass
									try:
										qzz1=qzz.split('composition')
										#writefile.write(u'<h4>%s: %s</h4>' % (cncharacter, qzz1[1].split('"')[2]))
										qzz2a=(qzz1[1]).split('{')
										qzz2b=qzz2a[1].split('}')
										qzz2=qzz2b[0].split('radical')
										#writefile.write(u'<h4>%s</h4>' % qzz2[0].replace('"',' '))
										qzz3=(qzz2b[1].split('matches'))
										#writefile.write(u'<h4>%s</h4>' % qzz3[0][1:-2].replace('"',' '))
									except:
										pass
						except:
							print(file)
						for i in tempfile[0:1]:
							#writefile.write(u'%s' % i)
							pass
						for i in tempfile[7:]:
							#writefile.write(u'%s' % i)
							pass
						#writefile.write(u'</html>')
					if pinyinword == 'False' or pinyinword == False:
						pass
					else:
						try:
							writefile.write(';;;%s:<a href="%s">%s (%s)</a></br>' % (pinyinword, writefilepath, pinyinword, cncharacter))
						except:
							print('error')
					writefilepath=False
					pinyinword=False
					cncharacter=False
writefile.close()

