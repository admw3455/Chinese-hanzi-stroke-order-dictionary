#create html directory
#cd into html directory
#run for i in *.html; do sed -i "s/a1b1c1q4q9q0d3/\'/g" $i; done
#run for i in *.html; do sed -i 's/blue/black/g' $i; done


import os
import HTMLParser
import io

with io.open('scc.txt', encoding='utf8') as scclist:
	scc=scclist.read()

cncharacter=False

htmlconverter = HTMLParser.HTMLParser()
with io.open('dictionary.txt', encoding='utf8') as dictionary:
	dictionaryfile=dictionary.readlines()

rootdir = os.getcwd()
for subdir, dirs, files in os.walk(rootdir):
	for file in files:
				if 'removelines.py' in file or '.html' in file or 'dictionary.txt' in file or 'createwordlist.py' in file or 'createdictionarylist.py' in file or 'scc.txt' in file or 'wordlist.txt' in file:
					pass
				else:
					openfile=file
					cncharactertemp="&#" + file.split('.')[0] + ";"
					cncharacter=htmlconverter.unescape(cncharactertemp)
					if cncharacter in scc:
						writefilepath=('html/' + openfile + '.html')
						writefile=io.open(writefilepath, 'a', encoding='utf8')
						with open(openfile) as file:
							tempfile = file.readlines()
							writefile.write(u'<html>')
						if len(tempfile) < 100:
							writefile.write(u'<meta http-equiv="refresh" content="8">')
						if len(tempfile) >= 100 and len(tempfile) < 200:
							writefile.write(u'<meta http-equiv="refresh" content="12">')
						if len(tempfile) >= 200 and len(tempfile) < 300:
							writefile.write(u'<meta http-equiv="refresh" content="16">')
						if len(tempfile) >= 300 and len(tempfile) < 400:
							writefile.write(u'<meta http-equiv="refresh" content="20">')
						if len(tempfile) >= 400:
							writefile.write(u'<meta http-equiv="refresh" content="24">')		
						try:
							for qzz in dictionaryfile:
								if (qzz[14:15]) == cncharacter:
									if 'definition' in qzz:
										pqzz1=qzz.split('pinyin')[1].split('[')[1].split(']')[0].replace('"','')
										if len(pqzz1) > 0:
											writefile.write(u'<h1>%s: %s (%s)</h1>' % (cncharacter, qzz.split('"')[7],pqzz1))
										else:
											writefile.write(u'<h1>%s: %s</h1>' % (cncharacter, qzz.split('"')[7]))
									else:
										pass
									try:
										qzz1=qzz.split('composition')
										writefile.write(u'<h4>%s: %s</h4>' % (cncharacter, qzz1[1].split('"')[2]))
										qzz2a=(qzz1[1]).split('{')
										qzz2b=qzz2a[1].split('}')
										qzz2=qzz2b[0].split('radical')
										writefile.write(u'<h4>%s</h4>' % qzz2[0].replace('"',' '))
										qzz3=(qzz2b[1].split('matches'))
										writefile.write(u'<h4>%s</h4>' % qzz3[0][1:-2].replace('"',' '))
									except:
										pass
						except:
							print(file)
						for i in tempfile[0:1]:
							writefile.write(u'%s' % i)
						for i in tempfile[7:]:
							writefile.write(u'%s' % i)
						writefile.write(u'</html>')
						writefile.close()
					cncharacter=False

