#!/bin/bash

if [ -d "dic/" ]; then
	echo "1 out of 3"
	for i in dic/*; do ./pinyinconvert.sh "$i"; done
	echo "2 out of 3"
	for i in dic/*; do sort -d "$i" -o "$i"; done
	echo "3 out of 3"
	for i in dic/*; do ./pinyinrevert.sh "$i"; done
	for i in dic/*; do sed -i "s/q0q0q0/\'/g" "$i"; done
	for i in dic/*; do sed -i '/^[[:space:]]*$/d' "$i"; done
	for i in dic/*; do sed -i  's/^[^:]*://g' "$i"; done
	#for i in dic/*; do sed -i  's/\n//g' "$i"; done
	echo "Done"
else
	echo "Needs dic directory"
fi
