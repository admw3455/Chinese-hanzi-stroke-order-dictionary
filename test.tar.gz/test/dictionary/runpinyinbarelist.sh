#!/bin/bash

if [ -f pinyinbarelist.html ]; then
	sort -d pinyinbarelist.html -o pinyinbarelist.html
	sed -i '/^[[:space:]]*$/d' pinyinbarelist.html
	sed -i  's/^[^:]*://g' pinyinbarelist.html
else
	echo "pinyinbarelist.html not present"
	exit
fi
