#!/bin/bash
for i in dic/*; do cat insert.txt | cat - "$i" > temp && mv temp "$i"; done
for i in dic/*; do echo "/html" >> "$i"; done
