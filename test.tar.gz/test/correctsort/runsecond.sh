#!/bin/bash
cd wordfiles
for i in *; do echo "${i%.*}" >> filelist.txt; done
echo "" >> filelist.txt
mv filelist.txt ../
cd ..
sort -d filelist.txt -o filelist.txt
echo "Replace \n with .txt\n in editor"
