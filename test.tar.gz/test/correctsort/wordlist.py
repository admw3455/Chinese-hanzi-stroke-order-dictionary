# -*- coding: utf-8-*-
import os
import HTMLParser
import io

with io.open('wordlist.txt', encoding='utf8') as wordlist:
	wordlistfile=wordlist.readlines()

for i in wordlistfile:
	q=i.split(':')
	pinyinbare=q[0].replace(u":","").replace(u"ā","a").replace(u"á","a").replace(u"ǎ","a").replace(u"à","a").replace(u"ē","e").replace(u"é","e").replace(u"ě","e").replace(u"è","e").replace(u"ī","i").replace(u"í","i").replace(u"ǐ","i").replace(u"ì","i").replace(u"ō","o").replace(u"ó","o").replace(u"ǒ","o").replace(u"ò","o").replace(u"ū","u").replace(u"ú","u").replace(u"ǔ","u").replace(u"ù","u").replace(u"ǖ","u").replace(u"ǘ","u").replace(u"ǚ","u").replace(u"ǜ","u")
	writefilepath=('wordfiles/%s.txt' % pinyinbare)
	writefile=io.open(writefilepath, 'a', encoding='utf8')
	writefile.write(q[0] + ':' + q[1])
	writefile.close()
