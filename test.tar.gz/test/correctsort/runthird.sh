#!/bin/bash
rm wordlist.txt
while read p; do cat wordfiles/"$p" >> wordlist.txt; done < filelist.txt 
rm filelist.txt
tr -d '\n' < wordlist.txt >> temp.txt
rm wordlist.txt
mv temp.txt wordlist.txt
