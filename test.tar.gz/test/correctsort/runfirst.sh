#!/bin/bash

if [ -d "wordfiles/" ]; then
	echo "1 out of 3"
	for i in wordfiles/*; do ./pinyinconvert.sh "$i"; done
	echo "2 out of 3"
	for i in wordfiles/*; do sort -d "$i" -o "$i"; done
	echo "3 out of 3"
	for i in wordfiles/*; do ./pinyinrevert.sh "$i"; done
	for i in wordfiles/*; do sed -i "s/q0q0q0/\'/g" "$i"; done
	for i in wordfiles/*; do sed -i '/^[[:space:]]*$/d' "$i"; done
	for i in wordfiles/*; do sed -i  's/^[^:]*://g' "$i"; done
	#for i in dic/*; do sed -i  's/\n//g' "$i"; done
	echo "Done"
else
	echo "Needs wordfiles directory"
fi
